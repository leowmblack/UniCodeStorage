package com.example.seng303assignment_leoblack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.seng303assignment_leoblack.composables.EventPage
import com.example.seng303assignment_leoblack.composables.Home
import com.example.seng303assignment_leoblack.composables.NewEventPage
import com.example.seng303assignment_leoblack.composables.ReportPage
import com.example.seng303assignment_leoblack.composables.VisitorPage
import com.example.seng303assignment_leoblack.ui.theme.SENG303AssignmentLeoBlackTheme
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel
import com.example.seng303assignment_leoblack.viewmodels.NewEventViewModel
import com.example.seng303assignment_leoblack.viewmodels.VisitorViewModel

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SENG303AssignmentLeoBlackTheme {
                val navController = rememberNavController()
                val currentPage = navController.currentBackStackEntryAsState()
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(stringResource(R.string.app_name)) },
                            navigationIcon = {
                                if (currentPage.value?.destination?.route != "Home") {
                                    IconButton(onClick = { navController.popBackStack() }) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowBack,
                                            contentDescription = stringResource(R.string.back)
                                        )
                                    }
                                }

                            }
                        )
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        val eventViewModel: EventViewModel = viewModel()
                        val memberViewModel: MemberViewModel = viewModel()
                        val visitorViewModel: VisitorViewModel = viewModel()
                        val newEventViewModel: NewEventViewModel = viewModel()
                        NavHost(navController = navController, startDestination = "Home") {
                            composable("Home") {
                                Home(navController = navController, eventViewModel)
                            }
                            composable(
                                "EventPage/{eventId}",
                                arguments = listOf(navArgument("eventId") {
                                    type = NavType.StringType
                                })
                                ) { backStackEntry ->
                                val eventId = backStackEntry.arguments?.getString("eventId")
                                eventId?.let { eventIdParam: String -> EventPage(
                                    eventIdParam,
                                    eventViewModel = eventViewModel,
                                    memberViewModel = memberViewModel,
                                    navController = navController
                                ) }
                            }
                            composable("VisitorPage/{eventId}",
                                arguments = listOf(navArgument("eventId") {
                                    type = NavType.StringType
                                })
                                ) { backStackEntry ->
                                val eventId = backStackEntry.arguments?.getString("eventId")
                                eventId?.let { eventIdParam: String -> VisitorPage(
                                    eventIdParam,
                                    navController = navController,
                                    firstName = visitorViewModel.firstName,
                                    onFirstNameChange = { newFirstName ->
                                        visitorViewModel.updateFirstName(newFirstName)
                                    },
                                    lastName = visitorViewModel.lastName,
                                    onLastNameChange = { newLastName ->
                                        visitorViewModel.updateLastName(
                                            newLastName
                                        )
                                    },
                                    group = visitorViewModel.group,
                                    onGroupChange = { newGroup ->
                                        visitorViewModel.updateGroup(
                                            newGroup
                                        )
                                    },
                                    memberViewModel = memberViewModel,
                                    eventViewModel = eventViewModel
                                    )
                                }
                            }
                            composable(
                                "ReportPage/{eventId}",
                                arguments = listOf(navArgument("eventId") {
                                    type = NavType.StringType
                                })
                            ) { backStackEntry ->
                                val eventId = backStackEntry.arguments?.getString("eventId")
                                eventId?.let { eventIdParam: String -> ReportPage(
                                    eventId = eventIdParam,
                                    memberViewModel = memberViewModel,
                                    eventViewModel = eventViewModel
                                ) }
                            }
                            composable(
                                "NewEventPage"
                            ) {
                                NewEventPage(
                                    navController,
                                    eventViewModel,
                                    title = newEventViewModel.title,
                                    onTitleChange = { newTitle ->
                                        newEventViewModel.updateTitle(newTitle)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}