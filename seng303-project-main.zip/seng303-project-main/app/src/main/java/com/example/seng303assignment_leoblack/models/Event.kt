package com.example.seng303assignment_leoblack.models

import kotlinx.serialization.Serializable

@Serializable
data class Event(
    val id: Int,
    val title: String,
    val memberInfo: List<AttendanceData>
) {
    companion object {
        fun getEvents(): List<Event> {
            return listOf(
                Event(
                    1,
                    "Event A",
                    memberInfo = listOf(
                        AttendanceData.emptyAttendance(1),
                        AttendanceData.emptyAttendance(2),
                        AttendanceData.emptyAttendance(3),
                        AttendanceData.emptyAttendance(4)
                    )
                ),
                Event(
                    2,
                    "Event B",
                    memberInfo = listOf(
                        AttendanceData.emptyAttendance(1),
                        AttendanceData.emptyAttendance(3),
                        AttendanceData.emptyAttendance(4)
                    )
                ),
                Event(
                    3,
                    "Event C",
                    memberInfo = listOf(
                        AttendanceData.emptyAttendance(1),
                        AttendanceData.emptyAttendance(4)
                    )
                ),
            )
        }
    }
}