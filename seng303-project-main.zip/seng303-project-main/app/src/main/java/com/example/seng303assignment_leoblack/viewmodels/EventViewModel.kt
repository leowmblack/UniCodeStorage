package com.example.seng303assignment_leoblack.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.seng303assignment_leoblack.models.AttendanceData
import com.example.seng303assignment_leoblack.models.Event
import com.example.seng303assignment_leoblack.utils.eventDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EventViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val store = context.eventDataStore

    val events: StateFlow<List<Event>> = store.data
        .onStart {
            if (store.data.first().isEmpty()) {
                store.updateData { Event.getEvents() }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    fun addEvent(event: Event) = update { it + event }


    fun getEventByEventId(eventId: Int): Event {
        return events.value.first { eventId == it.id }
    }

    fun getMembersByEventId(eventId: Int): StateFlow<List<Int>> {
//      gets a list of the id values stored in the memberInfo field
//      uses state stuff to make sure android recomposes,
//      refreshing the member list after a visitor is added
        return events.map { list ->
            list.firstOrNull {it.id == eventId }?.memberInfo?.map { it.memberId } ?: emptyList()
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )
    }

    fun addMemberToEvent(eventId: Int, memberId: Int) = update { list ->
//      finds the specified event and adds the member to it
//      (currently just for adding visitors to event)
        list.map { event ->
            if (eventId == event.id) {
                event.copy(memberInfo = event.memberInfo + AttendanceData.emptyAttendance(memberId))
            } else event
        }
    }

    /**
     * finds the member's info in the memberInfo AttendanceData list, checks them in,
     * and adds a timestamp to their checkInTimestamps list,
     * then adds the event to their list of checked in events
    */
    fun checkInMember(eventId: Int, memberId: Int, memberViewModel: MemberViewModel) = update { list ->
        list.map { event ->
            if (event.id == eventId) {
                val newMemberInfo = event.memberInfo.map { attendanceData ->
                    if (memberId == attendanceData.memberId) {
//                      Adds the current time as a timestamp in the member's list of check ins
                        attendanceData.copy(checkInTimestamps = attendanceData.checkInTimestamps + System.currentTimeMillis())
                    } else attendanceData
                }
//              finally, tell the member that they have checked in
                memberViewModel.addEventToCheckedInEvents(memberId, event.id)
//              and update the event's info for that member
                event.copy(memberInfo = newMemberInfo)
            } else event

        }
    }

    /**
     * finds the member's info in the memberInfo AttendanceData list, checks them out,
     * and adds a timestamp to their checkOutTimestamps list
     */
    fun checkOutMember(eventId: Int, memberId: Int, memberViewModel: MemberViewModel) = update { list ->
        list.map { event ->
            if (event.id == eventId) {
                val newMemberInfo = event.memberInfo.map { attendanceData ->
                    if (memberId == attendanceData.memberId) {
//                      gets the length of time the member was signed in for
                        val timeElapsed = System.currentTimeMillis() - attendanceData.checkInTimestamps.last()
                        attendanceData.copy(
//                          Adds the current time as a timestamp in the member's list of check outs
                            checkOutTimestamps = attendanceData.checkOutTimestamps + System.currentTimeMillis(),
//                          Also updates the member's total attendance for that event
                            timeAttended = attendanceData.timeAttended + timeElapsed
                        )
                    } else attendanceData
                }
//              finally, tell the member that they have checked out
                memberViewModel.removeEventFromCheckedInEvents(memberId, event.id)
//              and update the event's info for that member
                event.copy(memberInfo = newMemberInfo)
            } else event
        }
    }

    private fun update(block: (List<Event>) -> List<Event>) {
        viewModelScope.launch(Dispatchers.IO) {
            store.updateData(block)
        }
    }

}