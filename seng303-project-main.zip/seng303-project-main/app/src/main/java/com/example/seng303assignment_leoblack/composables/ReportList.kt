package com.example.seng303assignment_leoblack.composables

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.models.Event
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel

@Composable
fun ReportList(event: Event, memberViewModel: MemberViewModel, eventViewModel: EventViewModel) {
    val members by memberViewModel.members.collectAsStateWithLifecycle()
    val eventAttendees by eventViewModel.getMembersByEventId(event.id)
        .collectAsStateWithLifecycle()
    val groupSet = emptySet<String>().toMutableSet()
    for (member in members) {
        if (eventAttendees != null) {
            if (member.id in eventAttendees) {
                groupSet += member.group
            }
        }
    }
    LazyColumn {
        items(groupSet.toMutableList().sorted()) { group ->
            Text(group, style = MaterialTheme.typography.headlineLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Column (modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.first_name), fontWeight = FontWeight.Bold)
                    members.forEach { member ->
                        if (eventAttendees != null) {
                            if (member.group == group && member.id in eventAttendees) {
                                Text(member.firstName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                Column (modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.last_name), fontWeight = FontWeight.Bold)
                    members.forEach { member ->
                        if (eventAttendees != null) {
                            if (member.group == group && member.id in eventAttendees) {
                                Text(member.lastName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.time_attended), fontWeight = FontWeight.Bold)
                    members.forEach { member ->
                        if (eventAttendees != null) {
                            if (member.group == group && member.id in eventAttendees) {
                                val memberInfo = event.memberInfo.first{ it.memberId == member.id }
                                val stillCheckedIn = event.id in member.checkedInEvents
//                              ChatGPT code to make Time Attended readable
                                val durationMillis = memberInfo.timeAttended
                                val seconds = (durationMillis / 1000) % 60
                                val minutes = (durationMillis / (1000 * 60)) % 60
                                val hours = (durationMillis / (1000 * 60 * 60))

                                val formattedTime = buildString {
                                    if (stillCheckedIn) append("*")
                                    if (hours > 0) append("${hours}h ")
                                    if (minutes > 0 || hours > 0) append("${minutes}m ")
                                    append("${seconds}s")
                                }
//                              End of ChatGPT code block

                                if (stillCheckedIn) {
                                    Text(formattedTime, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFFB00020))
                                } else {
                                    Text(formattedTime, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }

                            }
                        }
                    }
                }
            }
            HorizontalDivider()
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
