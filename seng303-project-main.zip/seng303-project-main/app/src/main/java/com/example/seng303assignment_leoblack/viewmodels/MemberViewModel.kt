package com.example.seng303assignment_leoblack.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.seng303assignment_leoblack.models.Member
import com.example.seng303assignment_leoblack.utils.memberDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MemberViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val store = context.memberDataStore
    val members: StateFlow<List<Member>> = store.data
        .onStart {
            if (store.data.first().isEmpty()) {
                store.updateData { Member.getEventAMembers() }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    fun addMember(member: Member) = update { it + member }

    fun addEventToCheckedInEvents(memberId: Int, eventId: Int) = update { list ->
        list.map {
            if (it.id == memberId && eventId !in it.checkedInEvents) {
                it.copy(checkedInEvents = it.checkedInEvents + eventId)
            } else it
        }
    }

    fun removeEventFromCheckedInEvents(memberId: Int, eventId: Int) = update { list ->
        list.map {
            if (it.id == memberId && eventId in it.checkedInEvents) {
                it.copy(checkedInEvents = it.checkedInEvents - eventId)
            } else it
        }
    }

//    Is deleteMember needed?
//    fun deleteMember(member: Member) = update { it - member }

    private fun update(block: (List<Member>) -> List<Member>) {
        viewModelScope.launch(Dispatchers.IO) {
            store.updateData(block)
        }
    }
}