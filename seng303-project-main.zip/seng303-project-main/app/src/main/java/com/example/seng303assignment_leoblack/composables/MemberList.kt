package com.example.seng303assignment_leoblack.composables

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.models.Member
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel


@Composable
fun MemberList(eventId: String, memberViewModel: MemberViewModel, eventViewModel: EventViewModel) {
//    gets the member list stored in members.json
    val members by memberViewModel.members.collectAsStateWithLifecycle()
    val eventAttendees by eventViewModel.getMembersByEventId(eventId.toInt())
        .collectAsStateWithLifecycle()
    LazyColumn {
        items(members) { member ->
            if (eventAttendees != null) {
                if (member.id in eventAttendees) {
                    MemberCard(eventId, member, eventViewModel, memberViewModel)
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun MemberCard(eventId: String, member: Member, eventViewModel: EventViewModel, memberViewModel: MemberViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(30.dp),
    ) {
        Column {
            Icon(
                Icons.Outlined.AccountCircle,
                contentDescription = stringResource(R.string.member_profile),
                modifier = Modifier.size(40.dp)
            )
        }
        Column(
            modifier = Modifier
                .padding(10.dp, 0.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${member.firstName} ${member.lastName}",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(130.dp),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
                if (member.isVisitor) {
                    Text(
                        text = stringResource(R.string.visitor),
                        fontStyle = FontStyle.Italic
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = member.group,
                    modifier = Modifier.width(130.dp),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
                if (eventId.toInt() !in member.checkedInEvents) {
                    Button(onClick = { eventViewModel.checkInMember(eventId.toInt(), member.id, memberViewModel) }) {
                        Text(stringResource(R.string.check_in), style = MaterialTheme.typography.titleLarge)
                    }
                } else {
                    Button(onClick = { eventViewModel.checkOutMember(eventId.toInt(), member.id, memberViewModel) }) {
                        Text(stringResource(R.string.check_out), style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
        }
    }
}