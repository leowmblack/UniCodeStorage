package com.example.seng303assignment_leoblack.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.Serializer
import androidx.datastore.dataStore
import com.example.seng303assignment_leoblack.models.Event
import com.example.seng303assignment_leoblack.models.Member
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.InputStream
import java.io.OutputStream

val Context.memberDataStore: DataStore<List<Member>> by dataStore(
    fileName = "members.json",
    serializer = MemberSerialize
)

object MemberSerialize : Serializer<List<Member>> {
    override val defaultValue: List<Member> = emptyList()

    override suspend fun readFrom(input: InputStream): List<Member> =
        runCatching {
            Json.decodeFromString<List<Member>>(input.readBytes().decodeToString())
        }.getOrDefault(emptyList())

    override suspend fun writeTo(t: List<Member>, output: OutputStream) {
        withContext(Dispatchers.IO) {
            output.write(Json.encodeToString(t).toByteArray())
        }
    }
}

val Context.eventDataStore: DataStore<List<Event>> by dataStore(
    fileName = "events.json",
    serializer = EventSerialize
)

object EventSerialize : Serializer<List<Event>> {
    override val defaultValue: List<Event> = emptyList()

    override suspend fun readFrom(input: InputStream): List<Event> =
        runCatching {
            Json.decodeFromString<List<Event>>(input.readBytes().decodeToString())
        }.getOrDefault(emptyList())

    override suspend fun writeTo(t: List<Event>, output: OutputStream) {
        withContext(Dispatchers.IO) {
            output.write(Json.encodeToString(t).toByteArray())
        }
    }
}