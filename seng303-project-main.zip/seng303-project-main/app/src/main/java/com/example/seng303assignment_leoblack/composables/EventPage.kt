package com.example.seng303assignment_leoblack.composables

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.models.Event
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel

@Composable
fun EventPage(eventId: String, navController: NavController, eventViewModel: EventViewModel, memberViewModel: MemberViewModel) {
    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    val events by eventViewModel.events.collectAsStateWithLifecycle()
    val event: Event = events.first { event -> event.id == eventId.toInt()}
    if (isPortrait) {
        Row(
            modifier = Modifier.fillMaxSize()
                .padding(50.dp, 0.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(event.title, style = MaterialTheme.typography.displaySmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(140.dp))
                Button(onClick = { navController.navigate("VisitorPage/${event.id}") },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4CAF50),
                        contentColor = Color.White
                    )
                ) {
                    Text(stringResource(R.string.visitor_button), style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
        Row(
            modifier = Modifier
                .height(700.dp)
                .padding(0.dp, 70.dp)
        ) {
            MemberList(eventId, memberViewModel, eventViewModel)
        }
        Row(
            modifier = Modifier
                .padding(top=650.dp, start=200.dp)
        ) {
            Button(
                onClick = { navController.navigate("ReportPage/${event.id}") },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF38383E),
                    contentColor = Color.White
                )) {
                Text(stringResource(R.string.report_button), style = MaterialTheme.typography.headlineMedium)}
        }
    } else {
        Row(
            modifier = Modifier.fillMaxSize()
                .padding(50.dp, 0.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(event.title, style = MaterialTheme.typography.displaySmall,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(440.dp))
                Row {
                    Button(onClick = { navController.navigate("VisitorPage/${event.id}") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF4CAF50),
                            contentColor = Color.White
                        )
                    ) {
                        Text(stringResource(R.string.visitor_button), style = MaterialTheme.typography.headlineSmall)
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Button(
                        onClick = { navController.navigate("ReportPage/${event.id}") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF38383E),
                            contentColor = Color.White
                        )) {
                        Text(stringResource(R.string.report_button), style = MaterialTheme.typography.headlineMedium)
                    }
                }

            }
        }
        Row(
            modifier = Modifier
                .height(700.dp)
                .padding(0.dp, 70.dp)
        ) {
            MemberList(eventId, memberViewModel, eventViewModel)
        }
    }
}