package com.example.seng303assignment_leoblack.composables

import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.models.Member
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun VisitorPage(
    eventId: String,
    navController: NavController,
    firstName: String,
    onFirstNameChange: (String) -> Unit,
    lastName: String,
    onLastNameChange: (String) -> Unit,
    group: String,
    onGroupChange: (String) -> Unit,
    memberViewModel: MemberViewModel,
    eventViewModel: EventViewModel
) {
    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    var checkInImmediately by remember { mutableStateOf(true) }

    Scaffold(
//      establishes a snackbar that's used as an error message
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = if (isPortrait) {
                    Modifier
                        .width(380.dp)
//                  moves the snackbar to the top right of the screen if portrait
                        .padding(bottom = 680.dp, start = 180.dp)
                } else {
                    Modifier
                        .width(380.dp)
                }

            )}
    ) { padding ->
        Column(
            modifier = Modifier
                .verticalScroll(scrollState)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                Modifier.padding(bottom = 20.dp)
            ) {
                Text(stringResource(R.string.add_visitor), style = MaterialTheme.typography.displaySmall)
            }
            Row {
                Text(stringResource(R.string.all_fields_required), fontStyle = FontStyle.Italic, color = Color(0xFFB00020))
            }
            OutlinedTextField(
                value = firstName,
                onValueChange = { onFirstNameChange(it) },
                label = { Text(stringResource(R.string.first_name)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
            OutlinedTextField(
                value = lastName,
                onValueChange = { onLastNameChange(it) },
                label = { Text(stringResource(R.string.last_name)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
            OutlinedTextField(
                value = group,
                onValueChange = { onGroupChange(it) },
                label = { Text(stringResource(R.string.group)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )
            Row {
                Checkbox(
                    checked = checkInImmediately,
                    onCheckedChange = {checkInImmediately = it},
                )
                Text(stringResource(R.string.sign_in_checkbox), style = MaterialTheme.typography.headlineSmall)
            }

            Button(
                onClick = {
                    if (firstName.isNotBlank() && lastName.isNotBlank() && group.isNotBlank()) {
//                      creates the member, and checks them in if specified
                        val member = if (checkInImmediately) {
                            Member(Random.nextInt(0, Int.MAX_VALUE), firstName, lastName, group, isVisitor = true, checkedInEvents = setOf(eventId.toInt()))
                        } else {
                            Member(Random.nextInt(0, Int.MAX_VALUE), firstName, lastName, group, isVisitor = true, checkedInEvents = emptySet())
                        }
//                      also checks them in to the event if specified
                        memberViewModel.addMember(member)
                        eventViewModel.addMemberToEvent(eventId.toInt(), member.id)
                        if (checkInImmediately) eventViewModel.checkInMember(eventId.toInt(), member.id, memberViewModel)

//                      resets the entry fields
                        onFirstNameChange("")
                        onLastNameChange("")
                        onGroupChange("")
//                      alerts the user that a member has been added
                        Toast.makeText(context, context.getString(R.string.added_to_event, member.firstName, member.lastName), Toast.LENGTH_LONG).show()
                        navController.popBackStack()
                    } else {
                        coroutineScope.launch {
//                          shows the error snackbar
                            snackbarHostState.showSnackbar(
                                message = context.getString(R.string.please_fill_all_fields),
                                duration = SnackbarDuration.Short
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text(text = stringResource(R.string.add_visitor))
            }
        }
    }
}