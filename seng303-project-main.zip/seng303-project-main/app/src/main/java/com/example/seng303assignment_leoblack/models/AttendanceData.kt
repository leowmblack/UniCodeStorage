package com.example.seng303assignment_leoblack.models

import kotlinx.serialization.Serializable
import kotlin.random.Random

/**
 * Stores the data associated with a member of an event.
 * Tracks their check-in times, check-out times,
 * and calculates their total attendance time.
 */
@Serializable
data class AttendanceData (
    val id: Int,
    val memberId: Int,
    val checkInTimestamps: List<Long>,
    val checkOutTimestamps: List<Long>,
    val timeAttended: Long
) {
    companion object {
        fun emptyAttendance(memberId: Int): AttendanceData {
            return AttendanceData(
                id = Random.nextInt(0, Int.MAX_VALUE),
                memberId = memberId,
                checkInTimestamps = emptyList(),
                checkOutTimestamps = emptyList(),
                timeAttended = 0
            )
        }
    }
//  up next: add timeAttended logic
}