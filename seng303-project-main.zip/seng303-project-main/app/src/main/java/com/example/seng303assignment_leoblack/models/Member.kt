package com.example.seng303assignment_leoblack.models

import kotlinx.serialization.Serializable

@Serializable
data class Member(
    val id: Int,
    val firstName: String,
    val lastName: String,
    val group: String,
    val isVisitor: Boolean = false,
    val checkedInEvents: Set<Int> = emptySet()
) {
    companion object {
        fun getEventAMembers(): List<Member> {
            return listOf(
                Member(
                    1,
                    "Person",
                    "One",
                    "Group 1",
                ),
                Member(
                    2,
                    "Person",
                    "Two",
                    "Group 1",
                ),
                Member(
                    3,
                    "Person",
                    "Three",
                    "Group 2",
                ),
                Member(
                    4,
                    "Person",
                    "Four",
                    "Group 2",
                ),
            )
        }
    }
}

