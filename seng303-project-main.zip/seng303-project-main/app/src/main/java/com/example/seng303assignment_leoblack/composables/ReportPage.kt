package com.example.seng303assignment_leoblack.composables

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.createBitmap
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import com.example.seng303assignment_leoblack.viewmodels.MemberViewModel
import java.io.File

@Composable
fun ReportPage(eventId: String, eventViewModel: EventViewModel, memberViewModel: MemberViewModel) {
    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    val context = LocalContext.current
    val activity = context as Activity
    val event = eventViewModel.getEventByEventId(eventId.toInt())

    if (isPortrait) {
        Column(
            modifier = Modifier.padding(start = 20.dp)
        ) {
            Row {
                Text(
                    stringResource(R.string.report_for, event.title), style = MaterialTheme.typography.displaySmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(modifier = Modifier.padding(vertical = 10.dp)) {
                Text(stringResource(R.string.timing_notice), fontStyle = FontStyle.Italic, color = Color(0xFFB00020))
            }
            Row(modifier = Modifier.height(600.dp)) {
                ReportList(event, memberViewModel, eventViewModel)
            }
            Row(modifier = Modifier.padding(start = 180.dp)) {
                Button(onClick = { activity.let { it ->
                    val bitmap = takeScreenshot(it)
                    val reportFile = saveScreenshot(bitmap, it, event.title)
                    reportFile.let {
                        if (it != null) {
                            shareScreenshot(it, activity)
                        }
                    }
                }},
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB00020),
                        contentColor = Color.White
                    )) {
                    Text(stringResource(R.string.save_report_button), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    } else {
        Column(
            modifier = Modifier.padding(start = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 30.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    stringResource(R.string.report_for, event.title), style = MaterialTheme.typography.displaySmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(600.dp))
                Button(onClick = { activity.let { it ->
                    val bitmap = takeScreenshot(it)
                    val reportFile = saveScreenshot(bitmap, it, event.title)
                    reportFile.let {
                        if (it != null) {
                            shareScreenshot(it, activity)
                        }
                    }
                }},
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB00020),
                        contentColor = Color.White
                    )) {
                    Text(stringResource(R.string.save_report_button), style = MaterialTheme.typography.headlineMedium)
                }
            }
            Row(modifier = Modifier.padding(vertical = 10.dp)) {
                Text(stringResource(R.string.timing_notice), fontStyle = FontStyle.Italic, color = Color(0xFFB00020))
            }
            Row(modifier = Modifier.height(600.dp)) {
                ReportList(event, memberViewModel, eventViewModel)
            }
        }
    }
}

fun takeScreenshot(activity: Activity): Bitmap {
//  gets the current screen and turns it into a bitmap
//    (not the full screen, but close enough)
    val view = activity.window.decorView.rootView
    val bitmap = createBitmap(view.width, view.height)
    val canvas = Canvas(bitmap)
    view.draw(canvas)
    return bitmap
}

fun saveScreenshot(bitmap: Bitmap, activity: Activity, title: String): File? {
//  saves the screenshot to the app's directory
    val directory = activity.getExternalFilesDir(null)
    val file = File(directory, "$title Report.png")
    return try {
        file.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        file
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

fun shareScreenshot(file: File, activity: Activity) {
    val uri = androidx.core.content.FileProvider.getUriForFile(
        activity,
        "${activity.packageName}.provider",
        file)
    val intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_STREAM, uri)
        type = "image/png"
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    activity.startActivity(Intent.createChooser(intent, "Send report to:"))
}