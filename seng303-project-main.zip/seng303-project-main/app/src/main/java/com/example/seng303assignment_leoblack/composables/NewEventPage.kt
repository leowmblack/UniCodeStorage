package com.example.seng303assignment_leoblack.composables

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.seng303assignment_leoblack.R
import com.example.seng303assignment_leoblack.models.Event
import com.example.seng303assignment_leoblack.viewmodels.EventViewModel
import kotlin.random.Random

@Composable
fun NewEventPage(
    navController: NavController,
    eventViewModel: EventViewModel,
    title: String,
    onTitleChange: (String) -> Unit,
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .verticalScroll(scrollState)
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            Modifier.padding(bottom = 20.dp)
        ) {
            Text(
                stringResource(R.string.add_event_page),
                style = MaterialTheme.typography.displaySmall
            )
        }
        OutlinedTextField(
            value = title,
            onValueChange = { onTitleChange(it) },
            label = { Text(stringResource(R.string.title)) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )
        Button(
            onClick = {
                if (title.isNotBlank()) {
                    val event = Event(
                        Random.nextInt(0, Int.MAX_VALUE),
                        title = title,
                        memberInfo = emptyList()
                    )
                    eventViewModel.addEvent(event)
                    onTitleChange("")
                    navController.popBackStack()
                    Toast.makeText(context, context.getString(R.string.event_created, title), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, context.getString(R.string.event_fail), Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.create_event))
        }
    }
}