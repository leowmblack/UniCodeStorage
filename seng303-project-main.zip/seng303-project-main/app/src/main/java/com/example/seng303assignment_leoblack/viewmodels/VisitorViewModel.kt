package com.example.seng303assignment_leoblack.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class VisitorViewModel: ViewModel() {
    var firstName by mutableStateOf("")
        private set

    fun updateFirstName(newFirstName: String) {
        firstName = newFirstName
    }

    var lastName by mutableStateOf("")
        private set

    fun updateLastName(newLastName: String) {
        lastName = newLastName
    }

    var group by mutableStateOf("")
        private set

    fun updateGroup(newGroup: String) {
        group = newGroup
    }
}
