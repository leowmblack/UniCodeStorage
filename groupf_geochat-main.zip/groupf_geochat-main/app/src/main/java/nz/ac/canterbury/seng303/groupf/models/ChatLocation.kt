package nz.ac.canterbury.seng303.groupf.models
import kotlin.math.*
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlin.math.*

//allows us to yeet through savestate handle
@Parcelize
data class ChatRoom(val roomName: String, val numOfPeople: Int) : Parcelable

data class LatLng(val lat: Double, val lng: Double)
data class NearbyRoom(val room: ChatRoom, val at: ChatLocation, val distanceM: Int)
data class ChatLocation(
    val location: LatLng,
    val radius: Int, // meters
    val chatRooms: List<ChatRoom>,
) {
    companion object {
        fun getLocations(): List<ChatLocation> {
            return listOf(
                ChatLocation(
                    LatLng(-43.52253467306368, 172.5812084014045),
                    100,
                    listOf(ChatRoom("Jack Erskine", 121))
                ),
                ChatLocation(
                    LatLng(-43.522170879442164, 172.58166130790627),
                    90,
                    listOf(ChatRoom("Len Ley", 23))
                ),
                ChatLocation(
                    LatLng(-43.522343228537004, 172.58210603593972),
                    50,
                    listOf(ChatRoom("West Building", 115))
                ),
                ChatLocation(
                    LatLng(-43.4830774273886, 172.5974236705639),
                    200,
                    listOf(ChatRoom("Papanui", 2))
                ),
                ChatLocation(
                    LatLng(-43.521827630398185, 172.58405987152355),
                    170,
                    listOf(ChatRoom("Engineering Building", 10))
                )


            )
        }
    }
}

fun distanceMeters(a: LatLng, b:LatLng): Double {
    val R = 6371000.0
    val dLat = Math.toRadians(b.lat - a.lat)
    val dLng = Math.toRadians(b.lng - a.lng)
    val sin1 = sin(dLat / 2)
    val sin2 = sin(dLng / 2)
    val aa = sin1*sin1 + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin2 * sin2
    return 2 * R * atan2(sqrt(aa), sqrt(1 - aa))
}

//shows closest chatrooms
fun nearbyRooms(user: LatLng, locations: List<ChatLocation>): List<NearbyRoom> =
    locations.flatMap { loc ->
        val d = distanceMeters(user, loc.location).toInt()
        if (d <= loc.radius)
            loc.chatRooms.map { room -> NearbyRoom(room = room, at = loc, distanceM = d) }
        else emptyList()
    }.sortedBy { it.distanceM }