package nz.ac.canterbury.seng303.groupf.composables

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import nz.ac.canterbury.seng303.groupf.viewmodels.NearByRoomsViewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import android.net.Uri

//lists available chats, on clicking chats redirects to groupchat screen
@Composable
fun MessageScreen(
    navController: NavController,
    vm: NearByRoomsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    onRefreshLocation: () -> Unit
) {

    LaunchedEffect(Unit) { onRefreshLocation() }

    val rooms by vm.nearby.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Nearby Chat Rooms", style = MaterialTheme.typography.titleLarge)
            Button(onClick = onRefreshLocation) {
                Text("Refresh")
            }
        }

        if (rooms.isEmpty()) {
            Spacer(Modifier.padding(12.dp))
            Text("No chat rooms nearby. Move closer and tap Refresh.",
                style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn {
                items(rooms) { r ->
                    ListItem(
                        headlineContent = { Text(r.room.roomName) },
                        supportingContent = {
                            Text("${r.distanceM} m")
                        },
                        trailingContent = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon( imageVector = Icons.Default.Person,
                                    contentDescription = "Number of people in the chat",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.padding(horizontal = 4.dp))
                                Box(modifier = Modifier.width(40.dp), contentAlignment = Alignment.CenterEnd){
                                    Text("${r.room.numOfPeople}")
                                }
                            }

                        },
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .clickable {
                                val encoded = Uri.encode(r.room.roomName)
                                navController.navigate("Groupchat/$encoded")
                            }
                            .fillMaxSize()
                    )
                    HorizontalDivider(thickness = 3.dp)
                }
            }
        }
    }
}