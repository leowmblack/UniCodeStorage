package nz.ac.canterbury.seng303.groupf.composables

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import nz.ac.canterbury.seng303.groupf.models.Message
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow


@Composable
fun MessageList(messages: List<Message>, modifier: Modifier = Modifier) {

    val state = rememberLazyListState()
    val currUid = Firebase.auth.currentUser?.uid ?: ""

    // auto scroll the messages to bottom when new message been entered
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            state.animateScrollToItem(messages.lastIndex)
        }
    }

//  displays a scrollable list of the chat's previous messages
    LazyColumn(
        state = state,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
    ) {
        items(messages) { message ->
            val isUser = message.senderUid == currUid
            MessageBubble(message, isUser)
        }
    }
}