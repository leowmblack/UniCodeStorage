package nz.ac.canterbury.seng303.groupf.viewmodels

import nz.ac.canterbury.seng303.groupf.repo.ChatRepository
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import nz.ac.canterbury.seng303.groupf.models.Message


class ChatViewModel (private val roomName: String,
    private val repo: ChatRepository = ChatRepository()
    ): ViewModel() {

    val messages: StateFlow<List<Message>> = repo.listenMessagees(roomName)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun send(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            repo.sendMessage(roomName, content)
        }
    }
}