package nz.ac.canterbury.seng303.groupf.viewmodels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class CreateMessageViewModel: ViewModel() {
    var content by mutableStateOf("")
        private set

    fun updateContent(newContent: String) {
        content = newContent
    }
}
