package nz.ac.canterbury.seng303.groupf.utils

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresPermission
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest

@SuppressLint("MissingPermission")
fun addGeofence(geofencingClient: GeofencingClient, context: Context, geofencePendingIntent: PendingIntent) {

    val jackGeofence = Geofence.Builder()
        .setRequestId("Jack Erskine")
        .setCircularRegion(
            -43.52253467306368, 172.5812084014045,
            100f // radius meters
        )
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(
            Geofence.GEOFENCE_TRANSITION_ENTER or
                    Geofence.GEOFENCE_TRANSITION_EXIT
        )
        .build()
    val lenlyeGeofence = Geofence.Builder()
        .setRequestId("Len Lye")
        .setCircularRegion(
            -43.522170879442164, 172.58166130790627,
            90f // radius meters
        )
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(
            Geofence.GEOFENCE_TRANSITION_ENTER or
                    Geofence.GEOFENCE_TRANSITION_EXIT
        )
        .build()
    val westGeofence = Geofence.Builder()
        .setRequestId("West")
        .setCircularRegion(
            -43.522343228537004, 172.58210603593972,
            50f // radius meters
        )
        .setExpirationDuration(Geofence.NEVER_EXPIRE)
        .setTransitionTypes(
            Geofence.GEOFENCE_TRANSITION_ENTER or
                    Geofence.GEOFENCE_TRANSITION_EXIT
        )
        .build()

    val geofencingRequest = GeofencingRequest.Builder()
        .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
        .addGeofence(jackGeofence)
        .addGeofence(lenlyeGeofence)
        .addGeofence(westGeofence)
        .build()

    geofencingClient.addGeofences(geofencingRequest, geofencePendingIntent)
        .addOnSuccessListener {
            Log.d("GEOFENCE", "Geofence added successfully")
        }
        .addOnFailureListener {
                e ->
            Log.e("GEOFENCE", "Failed to add geofence", e)
        }
}


