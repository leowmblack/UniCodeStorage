package nz.ac.canterbury.seng303.groupf.models

import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Serializable
data class Message(
    val id: Int,
    val senderId: Int,
    val senderUserName: String = "",
    val content: String,
    val timestamp: Long,
    val senderUid: String = ""
) {
//  helper function to display the message's timestamp in readable format
    fun readableTime(): String {
        val dateFormat = SimpleDateFormat("hh:mm a d MMM ", Locale.getDefault())
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = this.timestamp
        return dateFormat.format(calendar.time)
    }

    companion object {
//      makes a list of placeholder messages
        fun getMessages(): List<Message> {
            return listOf(
                Message(
                    1,
                    1,
                    content = "test",
                    timestamp =  1637753200000
                ),
                Message(
                    2,
                    1,
                    content = "test1",
                    timestamp =  1637853200000
                ),
                Message(
                    3,
                    1,
                    content = "test2",
                    timestamp =  1637953200000
                ),
                Message(
                    4,
                    1,
                    content = "test3",
                    timestamp = 1638653200000
                )
            )
        }
    }
}