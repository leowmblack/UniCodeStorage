package nz.ac.canterbury.seng303.groupf.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat

class GeofenceBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent) ?: return
        if (geofencingEvent.hasError()) {
            Log.e("GEOFENCE", "Error in geofencing event")
            return
        }
        when (geofencingEvent.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> {
                val fences = geofencingEvent.triggeringGeofences
                showNotification(context, "Enter", fences)
                Log.d("GEOFENCE", "Entered geofence ")
                }

            Geofence.GEOFENCE_TRANSITION_EXIT -> {
                val fences = geofencingEvent.triggeringGeofences
                showNotification(context, "Exit", fences)
                Log.d("GEOFENCE", "Exited geofence ")
            }
        }
    }
    private fun showNotification(context: Context, transition: String, fences: List<Geofence?>?) {
        val channelId = "geofence_channel"
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Geofence Notifications",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }
        val fenceNames = fences
            ?.filterNotNull()
            ?.joinToString(", ") { it.requestId }

        val title = when (transition) {
            "Enter" -> "Entering Chat location for:"
            "Exit" -> "Exiting Chat location for:"
            else -> "Geofence Triggered"
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
            .setContentText(fenceNames)
            .setSmallIcon(android.R.drawable.ic_dialog_map)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}

