package nz.ac.canterbury.seng303.groupf.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import nz.ac.canterbury.seng303.groupf.models.ChatLocation
import nz.ac.canterbury.seng303.groupf.models.LatLng
import nz.ac.canterbury.seng303.groupf.models.NearbyRoom
import nz.ac.canterbury.seng303.groupf.models.nearbyRooms

class NearByRoomsViewModel( private val locations: List<ChatLocation> = ChatLocation.getLocations()
): ViewModel(){
    private val _nearby = MutableStateFlow<List<NearbyRoom>>(emptyList())
    val nearby: StateFlow<List<NearbyRoom>> = _nearby

    fun updateUserLocatio(lat: Double, lng: Double) {
        val user = LatLng(lat, lng)
        _nearby.value = nearbyRooms(user, locations)
    }

    fun updateFromAndroidLocation(getLocation: suspend () -> android.location.Location?) {
        viewModelScope.launch {
            val loc = getLocation()
            if (loc != null) updateUserLocatio(loc.latitude, loc.longitude)
            else _nearby.value = emptyList()
        }
    }



}