package nz.ac.canterbury.seng303.groupf.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.Serializer
import androidx.datastore.dataStore
import kotlinx.serialization.json.Json
import nz.ac.canterbury.seng303.groupf.models.Message
import java.io.InputStream
import java.io.OutputStream

val Context.messageDataStore: DataStore<List<Message>> by dataStore(
    fileName = "messages.json",
    serializer = MessagesSerialize
)

object MessagesSerialize : Serializer<List<Message>> {
    override val defaultValue: List<Message> = emptyList()

    override suspend fun readFrom(input: InputStream): List<Message> =
        runCatching {
            Json.decodeFromString<List<Message>>(input.readBytes().decodeToString())
        }.getOrDefault(emptyList())

    override suspend fun writeTo(t: List<Message>, output: OutputStream) {
        output.write(Json.encodeToString(t).toByteArray())
    }
}

val Context.colourSchemeDataStore: DataStore<String> by dataStore(
    fileName = "colourscheme.json",
    serializer = ColourSchemeSerialize
)

object ColourSchemeSerialize : Serializer<String> {
    override val defaultValue: String = "Light Mode"

    override suspend fun readFrom(input: InputStream): String =
        runCatching {
            Json.decodeFromString<String>(input.readBytes().decodeToString())
        }.getOrDefault("Light Mode")

    override suspend fun writeTo(t: String, output: OutputStream) {
        output.write(Json.encodeToString(t).toByteArray())
    }
}

