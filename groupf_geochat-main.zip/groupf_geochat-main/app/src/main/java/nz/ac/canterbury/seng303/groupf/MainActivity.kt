package nz.ac.canterbury.seng303.groupf

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

import android.net.Uri

import android.location.Location
import android.os.Build

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts

import androidx.annotation.Nullable

import androidx.annotation.RequiresApi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
// icon imports
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.rounded.Place

//-----------------------------------------
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.google.android.gms.location.FusedLocationProviderClient
import nz.ac.canterbury.seng303.groupf.utils.addGeofence
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import nz.ac.canterbury.seng303.groupf.composables.GroupChatScreen
import nz.ac.canterbury.seng303.groupf.composables.MapScreen
import nz.ac.canterbury.seng303.groupf.composables.MessageScreen
import nz.ac.canterbury.seng303.groupf.composables.SettingsScreen
import nz.ac.canterbury.seng303.groupf.ui.theme.GroupFTheme
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import nz.ac.canterbury.seng303.groupf.viewmodels.ColourSchemeViewModel
import nz.ac.canterbury.seng303.groupf.utils.GeofenceBroadcastReceiver
import nz.ac.canterbury.seng303.groupf.viewmodels.NearByRoomsViewModel
import kotlin.coroutines.resume
import kotlin.math.log

class MainActivity : ComponentActivity() {


    private lateinit var auth: FirebaseAuth



    lateinit var geofencingClient: GeofencingClient
    private lateinit var geofencePendingIntent: PendingIntent

    private val fusedLocationClient by lazy {
        LocationServices.getFusedLocationProviderClient(this)
    }
    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        return fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED
    }

    private val requestLocationPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            requestBackgroundPermission()
        }
    }
    private val requestBackgroundPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                addGeofenceSafely()
            }
        }
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        }


    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = Firebase.auth
        // sign in anonymously, can add accounts later
        if (auth.currentUser == null) {
            auth.signInAnonymously()
        }



        enableEdgeToEdge()
        setContent {

//          gets the chosen colour scheme from the file "colourscheme.json"
            val colourSchemeViewModel: ColourSchemeViewModel = viewModel()
            val colourScheme by colourSchemeViewModel.colourScheme.collectAsStateWithLifecycle()

            GroupFTheme(colourSchemeChoice = colourScheme) {
                geofencingClient = LocationServices.getGeofencingClient(this)
                geofencePendingIntent = PendingIntent.getBroadcast(
                    this,
                    0,
                    Intent(this, GeofenceBroadcastReceiver::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )

                if (!hasLocationPermission()) {
                    requestLocationPerms.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                } else {
                    requestBackgroundPermission()
                }
                requestPostNotification()
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentScreen = navBackStackEntry?.destination?.route
                Scaffold(
                    topBar = {
                        TopAppBar(
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.surfaceBright
                            ),
                            title = { Text("GEOCHAT") },
                            navigationIcon = {
                                if (currentScreen == "GroupChat/{roomName}")

                                IconButton(onClick = { navController.popBackStack()}) {
                                    Icon(
                                        modifier = Modifier.size(30.dp),
                                        imageVector = Icons.Default.ArrowBack,
                                        contentDescription = "back",
                                        tint = MaterialTheme.colorScheme.surfaceBright,
                                        )

                                } else {
                                    IconButton(onClick = {}) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowBack,
                                            contentDescription = "",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        )
                    },
                    bottomBar = {
                        BottomAppBar(
                            containerColor = MaterialTheme.colorScheme.primary
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { navController.navigate("Message") }) {
                                    Icon(
                                        modifier = Modifier.size(40.dp),
                                        imageVector = Icons.Default.Chat,
                                        contentDescription = "Message",
                                        tint = MaterialTheme.colorScheme.surfaceBright,
                                    )
                                }
                                IconButton(onClick = { navController.navigate("Map") }) {
                                    Icon(
                                        modifier = Modifier.size(40.dp),

                                        imageVector = Icons.Rounded.Place,
                                        contentDescription = "Map" ,
                                        tint = MaterialTheme.colorScheme.surfaceBright
                                    )
                                }
                                IconButton(onClick = { navController.navigate("Settings") }) {
                                    Icon(
                                        modifier = Modifier.size(40.dp),

                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = MaterialTheme.colorScheme.surfaceBright
                                    )
                                }
                            }

                        }
                    }

                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "Message",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("Message") {
                            val vm: NearByRoomsViewModel = viewModel()
                            MessageScreen(
                                navController = navController,
                                onRefreshLocation = {
                                    if (!hasLocationPermission()) {
                                        requestLocationPerms.launch(arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        ))
                                    } else {
                                        lifecycleScope.launch {
                                            vm.updateFromAndroidLocation { getCurrentLocationOnceSafely() }
                                        }
                                    }
                                }
                            )
                        }
                        composable("Map") {
                            MapScreen(navController = navController)
                        }
                        composable("Settings") {
                            SettingsScreen(
                                navController = navController,
                                colourScheme = colourScheme,
                                colourSchemeViewModel = colourSchemeViewModel
                            )
                        }
//                      page for viewing group chats,

                        composable ("GroupChat/{roomName}",
                            arguments = listOf(navArgument("roomName"){type = NavType.StringType})
                        ){backStackEntry ->
                            val roomName = Uri.decode(backStackEntry.arguments?.getString("roomName") ?: "")
                            GroupChatScreen(roomName = roomName)
                        }

                    }
                }
            }
        }
    }
    private suspend fun getCurrentLocationOnceSafely(): Location? {

        if (!hasLocationPermission()) {
            return null
        }
        return try {
            val loc = suspendCancellableCoroutine<Location?> { cont ->
                fusedLocationClient.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY,
                    CancellationTokenSource().token
                ).addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resume(null) }
            }
            loc ?: suspendCancellableCoroutine { cont ->
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resume(null) }
            }
        } catch (se: SecurityException) {
            null
        }
    }
    private fun requestBackgroundPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestBackgroundPerm.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            } else {
                addGeofenceSafely()
            }
        } else {
            addGeofenceSafely() // Android < Q
        }
    }
    private fun addGeofenceSafely() {
        lifecycleScope.launch {
            val location = getCurrentLocationOnceSafely()
            if (location != null) {
                Log.d("GEOFENCE", "Got location: ${location.latitude}, ${location.longitude}. Adding geofence...")
                addGeofence(geofencingClient, applicationContext, geofencePendingIntent)
            } else {
                Log.e("GEOFENCE", "Failed to get location, geofence not added")
            }
        }
    }
    private fun requestPostNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}



