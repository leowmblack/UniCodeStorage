package nz.ac.canterbury.seng303.groupf.composables


import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng as GmsLatLng
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.maps.android.compose.*
import kotlinx.coroutines.suspendCancellableCoroutine
import nz.ac.canterbury.seng303.groupf.models.ChatLocation
import nz.ac.canterbury.seng303.groupf.models.LatLng as ModelLatLng
import kotlin.coroutines.resume
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.google.maps.android.compose.Circle

@Composable
fun MapScreen(
    modifier: Modifier = Modifier,
    navController: NavController
) {
    val context = LocalContext.current

    // Start with a neutral camera
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(GmsLatLng(-43.5223, 172.5790), 15.5f)
    }

    // Store user location (from emulator mock or device)
    var userLatLng by remember { mutableStateOf<GmsLatLng?>(null) }

    // fetch a one-shot current location if permission == true
    LaunchedEffect(Unit) {
        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            val fused = LocationServices.getFusedLocationProviderClient(context)
            val loc = getCurrentLocationOnce(fused) ?: fused.awaitLastLocation()
            loc?.let {
                val here = GmsLatLng(it.latitude, it.longitude)
                userLatLng = here
                cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(here, 17f))
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                isMyLocationEnabled = userLatLng != null
            ),
            uiSettings = MapUiSettings(
                myLocationButtonEnabled = true,
                zoomControlsEnabled = false
            )
        ) {
            //chatzones on map
            ChatLocation.getLocations().forEach { loc ->
                val center = loc.location.toGmsLatLng()

                Marker(
                    state = rememberMarkerState(position = center),
                    title = loc.chatRooms.firstOrNull()?.roomName ?: "Chat Zone",
                    snippet = "${loc.chatRooms.size} room(s)",
                    onInfoWindowClick = {
                        // TODO: route to a specific chat screen
                        navController.navigate("Message")
                    }
                )
                Circle(
                    center = center,
                    radius = loc.radius.toDouble(),
                    strokeWidth = 2f,
                    fillColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                    strokeColor = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }
    }
}

//latlng to googles latlng boundry
private fun ModelLatLng.toGmsLatLng(): GmsLatLng = GmsLatLng(lat, lng)

//accurate location settins, AI helped here
private suspend fun getCurrentLocationOnce(
    fused: FusedLocationProviderClient
): Location? = suspendCancellableCoroutine { cont ->
    try {
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { cont.resume(it) }
            .addOnFailureListener { cont.resume(null) }
    } catch (_: SecurityException) {
        cont.resume(null)
    }
}

//await function, AI help here
private suspend fun FusedLocationProviderClient.awaitLastLocation(): Location? =
    suspendCancellableCoroutine { cont ->
        try {
            lastLocation
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(null) }
        } catch (_: SecurityException) {
            cont.resume(null)
        }
    }