package nz.ac.canterbury.seng303.groupf.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import nz.ac.canterbury.seng303.groupf.utils.colourSchemeDataStore

class ColourSchemeViewModel(application: Application) : AndroidViewModel(application) {
    private val store = application.applicationContext.colourSchemeDataStore
    val colourScheme: StateFlow<String> = store.data
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = "Light Mode"
        )

    private fun update(block: (String) -> String) {
        viewModelScope.launch(Dispatchers.IO) {
            store.updateData(block)
        }
    }

    fun changeScheme(scheme: String) = update {scheme}
}