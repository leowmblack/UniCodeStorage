package nz.ac.canterbury.seng303.groupf.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import nz.ac.canterbury.seng303.groupf.models.Message
import nz.ac.canterbury.seng303.groupf.utils.messageDataStore

class MessageViewModel(application: Application) : AndroidViewModel(application) {
    private val store = application.applicationContext.messageDataStore
    val messages: StateFlow<List<Message>> = store.data
//      if message list is empty, this fills it with placeholder messages
//      (remove this for proper use)
        .onStart {
            if (store.data.first().isEmpty()) {
                store.updateData { Message.getMessages() }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private fun update(block: (List<Message>) -> List<Message>) {
        viewModelScope.launch(Dispatchers.IO) {
            store.updateData(block)
        }
    }

    fun addMessage(message: Message) = update {it + message}

}