package nz.ac.canterbury.seng303.groupf.repo

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import nz.ac.canterbury.seng303.groupf.models.Message
import kotlin.math.absoluteValue


class ChatRepository {
    private val auth by lazy { Firebase.auth}
    private val db by lazy { Firebase.firestore}

    fun listenMessagees(roomName: String) = callbackFlow<List<Message>>{
        val path = "rooms/$roomName/messages"
        //Log.d("ChatRepo", "Listening at: $path")
        // Listener registration
        val reg = db.collection("rooms")
            .document(roomName)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .limit(200)
            .addSnapshotListener { data, e -> // data if success
                if (e != null) {
                    close(e) // close the flow if an error occurs
                    return@addSnapshotListener}
                //Log.d("ChatRepo", "data size=${data?.size()} for $path")
                val list = data?.documents?.mapNotNull { doc ->
                    val id = doc.getLong("id")?.toInt() ?: 0
                    val senderUid = doc.getString("senderId") ?: "0"
                    val senderId = doc.getLong("id")?.toInt() ?: 0
                    val content = doc.getString("content") ?: ""
                    val tsMs =
                        doc.getTimestamp("timestamp")?.toDate()?.time
                            ?:  0L
                    val userID = (senderUid.hashCode().absoluteValue) % 10
                    Message(id = id, senderId = userID, content = content, timestamp = tsMs, senderUid = senderUid)
                } ?: emptyList()
                val sorted = list.sortedBy { it.timestamp }
                Log.d("ID", "${list}")
                //Log.d("List", "${list}")
                trySend(sorted)
            }
        awaitClose { reg.remove() }

    }

    suspend fun sendMessage(roomName: String, content: String) {
        val uid = auth.currentUser?.uid ?: "Unknown user"
        val map = hashMapOf(
            "id" to (System.nanoTime() % Int.MAX_VALUE).toInt(),
            "senderId" to uid,
            "content" to content,
            "timestamp" to FieldValue.serverTimestamp()
        )
        db.collection("rooms").document(roomName)
            .collection("messages")
            .add(map)
    }


}