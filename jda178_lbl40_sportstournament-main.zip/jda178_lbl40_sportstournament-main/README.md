A Sports Manager game based on the sport of Quadball.

Run the program:
java -jar jda178_lbl40_sportstournament.jar

Import project into Eclipse:
Copy this URL:
https://eng-git.canterbury.ac.nz/jda178/jda178_lbl40_sportstournament.git
Click on File > Import
Select Projects from Git in the Git folder, then click next
Select Clone URL, then click next
Paste the URL into the URL line, then click next
Log in
Check package is selected
Click Finish
